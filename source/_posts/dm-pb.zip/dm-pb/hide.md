---
title: 分段弹幕实现过程
type: "code"
---


### 背景
业务需求：

- 弹幕翻倍


调研结果：

- 文件大
- 解析慢
- 传输慢

> 总归一句话，为了更快



### 调研

- [pb与xml格式耗时对比](https://info.bilibili.co/pages/resumedraft.action?draftId=90137320&draftShareId=f98e3763-dae6-4a11-a824-52d2fc88209a&)
单位（ms）
![](/info.png)


总结：
一、 在没有worker的情况下：

弹幕少于2000条，差距不大，当大于2000条时，pb格式会更快一些

二、 在有worker的情况下：

弹幕少于4000条，pb格式会更快一些，

当大于4000条时，xml格式会更快一些（worker缓存原因，刷新时省去网络请求时间）

三、

自己生成的pb文件大概是XML文件的75%



### xml 弹幕
![](/xml.png)
``` javascript
let eAttr;
let data: IDanmakuData;
const danmakuArray = [];
const parseStartTime = +new Date();

const datas = result.match(/<d[\s\S]*?<\/d>/gi) || [];

const maxlimit = result.match(/<maxlimit[^>]*>(.*?)<\/maxlimit>/i);
const total = maxlimit ? maxlimit[1] : '-';

const stateMatch = result.match(/<state[^>]*>(.*?)<\/state>/i);
const state = stateMatch ? +stateMatch[1] : 0;

const sendMatch = result.match(/<text[^>]*>(.*?)<\/text>/i);
const sendTip = sendMatch ? sendMatch[1] : '';

const textSideMatch = result.match(/<text_side[^>]*>(.*?)<\/text_side>/i);
const textSide = textSideMatch ? textSideMatch[1] : '';

for (let i = 0, len = datas.length; i < len; i++) {
    const items = datas[i].match(/<d[^>]*p="(.*?)"[^>]*>([\s\S]*?)<\/d>/gi);
    if (!items) {
        continue;
    }
    const json = RegExp.$1.split(',');
    const text = RegExp.$2;
    let rnJson = [];
    if (typeof text === 'undefined') {
        continue;
    }
    data = {
        stime: Number(json[0]),
        mode: Number(json[1]),
        size: Number(json[2]),
        color: Number(json[3]),
        date: Number(json[4]),
        class: Number(json[5]),
        uid: json[6],
        dmid: String(json[7]),
        text: Number(json[1]) === 9 ? String(text) : String(text).replace(/(\/n|\\n|\n|\r\n)/g, '\r'),
    };
    if ((eAttr = /e="(.*?)"/gi.exec(datas[i])) !== null) {
        if (typeof eAttr[1] === 'string') {
            rnJson = eAttr[1].split(',');
            data.mid = +rnJson[0];
            data.uname = rnJson[1];
        }
    }
    data.text = data.text.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
    danmakuArray.push(data);
}

```

### pb弹幕实现方案

- 在请求弹幕之前会请求一个配置接口

> 最初只是为了把弹幕的配置信息放在这个接口，比如，多长时间为一段。后来这个接口扩展成这样；

``` typescript
interface IDmView {
    // state 弹幕区状态  0:打开 1:关闭弹幕区， 2弹幕升级
    state: number;
    text: string;

    textSide: string;
    //  分段弹幕配置
    dmSge: {
        pageSize: number;
        total: number;
    };

    flag: {
        recFlag: number;
        recText: string;
        recSwitch: number;
    };
    // 高级弹幕链接地址 （上传到bfs）
    specialDms: string[];
    // up主的checkbox 是否存在
    checkBox: boolean;
    //弹幕数
    count: number;
    // 指令弹幕数据
    commandDms: ICommandDm[];
    // 弹幕设置面板
    dmSetting: IDMSetting;
}
```

### pb弹幕代码实现
![](/img/pb.png)


``` javascript
// dm.proto
syntax = "proto3";
package bilibili.community.service.dm.v1;

// DanmakuElem .
message DanmakuElem {
    // 弹幕id
    int64 id = 1;
    // 弹幕位置
    int32 progress = 2;
    // 弹幕类型
    int32 mode = 3;
    // 弹幕字体
    int32 fontsize = 4;
    // 弹幕颜色
    uint32 color = 5;
    // 弹幕发送者md5哈希
    string midHash = 6;
    // 弹幕文本内容
    string content = 7;
    // 弹幕发送时间  时间戳
    int64 ctime = 8;
    // 弹幕权重 越高显示优先级越高
    int32 weight = 9;
    // 弹幕动作
    string action = 10;
    // 弹幕池
    int32 pool = 11;
    // 弹幕id_str
    string idStr = 12;
    // 弹幕属性   0保护弹幕 1：直播弹幕  2：高赞弹幕
    //    1 bit  |    1 bit   | 1 bit    |  1 bit   |   1 bit  |
    // --------------------------------------------------------
    //   ...     |    ...    | 高赞弹幕  |  直播弹幕  |  保护弹幕  |
    // --------------------------------------------------------
    int32 attr = 13;
}

```
> proto 转json
``` json
"scripts": {
    "pbjson": "pbjs -t json ./src/js/const/dm.proto > ./src/js/const/dm.json"
  },
```

``` typescript
import { Root } from 'protobufjs';
import dmproto from 'dm.json';

const data = ...... // arraybuffer

const root = Root.fromJSON(dmproto);
const type = root.lookupType(`bilibili.community.service.dm.v1.DanmakuElem`);

const msg = type.decode(new Uint8Array(data));

const dm: IDmData = type.toObject(msg);

interface IDmData {
    id: string;
    idStr: string;
    progress: number;
    mode: number;
    fontsize: number;
    color: number;
    midHash: string;
    content: string;
    ctime: number;
    weight: number;
    pool: number;
    attr: number;
    action?: string;
}

```

### [数据统计](http://berserker.bilibili.co/#/bi/report/all/item?id=13644&breadcrumb=%E5%88%86%E6%AE%B5%E5%B0%8F%E6%97%B6)

### [分段弹幕引起问题](https://info.bilibili.co/pages/viewpage.action?pageId=102987137)